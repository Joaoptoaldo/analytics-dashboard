#!/usr/bin/env python3
import os
from sqlalchemy import create_engine, text

NEON_URL = os.getenv('NEON_DATABASE_URL') or 'postgresql://neondb_owner:npg_kVbLoqca31Kv@ep-mute-sound-acp86gdj-pooler.sa-east-1.aws.neon.tech/neondb?sslmode=require&channel_binding=require'
engine = create_engine(NEON_URL, future=True)

with engine.begin() as conn:
    # Add is_synthetic if missing
    conn.execute(text("ALTER TABLE products ADD COLUMN IF NOT EXISTS is_synthetic BOOLEAN;"))
    # Ensure external_id exists
    conn.execute(text("ALTER TABLE products ADD COLUMN IF NOT EXISTS external_id TEXT;"))
    # Ensure other columns types exist (best-effort; ALTER IF NOT EXISTS is not available for types)
    # We'll add any missing columns as TEXT/NUMERIC/TIMESTAMP permissively
    try:
        conn.execute(text("ALTER TABLE products ADD COLUMN IF NOT EXISTS client TEXT;"))
        conn.execute(text("ALTER TABLE products ADD COLUMN IF NOT EXISTS category TEXT;"))
        conn.execute(text("ALTER TABLE products ADD COLUMN IF NOT EXISTS revenue NUMERIC;"))
        conn.execute(text("ALTER TABLE products ADD COLUMN IF NOT EXISTS status TEXT;"))
        conn.execute(text("ALTER TABLE products ADD COLUMN IF NOT EXISTS region TEXT;"))
        conn.execute(text("ALTER TABLE products ADD COLUMN IF NOT EXISTS date TIMESTAMP;"))
    except Exception:
        pass

print('SCHEMA_FIXED')
