#!/usr/bin/env python3
import json
import os
from pathlib import Path

import requests
from sqlalchemy import create_engine, text

BASE = 'http://127.0.0.1:8000/api'
OUT = Path('audit_evidence')
OUT.mkdir(exist_ok=True)

endpoints = {
    'overview': '/overview?period=all&category=all&status=all&search=',
    'sales_monthly': '/sales/monthly?period=all&category=all&status=all&search=',
    'sales_trend_30d': '/sales/trend?period=all&category=all&status=all&search=&range=30d',
    'distribution_category': '/distribution/category',
    'top_products': '/top/products?limit=10',
    'ticket_average': '/metrics/ticket-average?period=all&category=all&status=all&search=',
}

print('=== API JSON ===')
for name, path in endpoints.items():
    data = requests.get(BASE + path, timeout=10).json()
    (OUT / f'{name}.json').write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    print(f'{name}: saved -> {OUT / f"{name}.json"}')

neon_url = os.getenv('NEON_DATABASE_URL') or 'postgresql://neondb_owner:npg_kVbLoqca31Kv@ep-mute-sound-acp86gdj-pooler.sa-east-1.aws.neon.tech/neondb?sslmode=require&channel_binding=require'
engine = create_engine(neon_url, future=True)
with engine.connect() as conn:
    sql = {
        'total_orders': conn.execute(text('SELECT COUNT(*) FROM products')).scalar(),
        'total_revenue': float(conn.execute(text('SELECT COALESCE(SUM(revenue), 0) FROM products')).scalar() or 0),
        'total_customers': conn.execute(text('SELECT COUNT(DISTINCT client) FROM products')).scalar(),
        'completed_orders': conn.execute(text("SELECT COUNT(*) FROM products WHERE status = 'Completed'")).scalar(),
        'min_date': str(conn.execute(text('SELECT MIN(date) FROM products')).scalar()),
        'max_date': str(conn.execute(text('SELECT MAX(date) FROM products')).scalar()),
    }
    (OUT / 'sql_overview.json').write_text(json.dumps(sql, ensure_ascii=False, indent=2), encoding='utf-8')
    print('sql_overview: saved ->', OUT / 'sql_overview.json')

print('DONE')
