#!/usr/bin/env python3
import os
from sqlalchemy import create_engine, text

NEON_URL = os.getenv('NEON_DATABASE_URL') or 'postgresql://neondb_owner:npg_kVbLoqca31Kv@ep-mute-sound-acp86gdj-pooler.sa-east-1.aws.neon.tech/neondb?sslmode=require&channel_binding=require'
engine = create_engine(NEON_URL, future=True)

with engine.connect() as conn:
    current = conn.execute(text("SELECT to_regclass('public.products')")).scalar()
    old = conn.execute(text("SELECT to_regclass('public.products_old')")).scalar()
    total = conn.execute(text('SELECT COUNT(*) FROM products')).scalar()
    total_revenue = conn.execute(text('SELECT SUM(revenue) FROM products')).scalar()
    distinct_clients = conn.execute(text('SELECT COUNT(DISTINCT client) FROM products')).scalar()
    min_date = conn.execute(text('SELECT MIN(date) FROM products')).scalar()
    max_date = conn.execute(text('SELECT MAX(date) FROM products')).scalar()

print('NEON products after swap:')
print('  products_table:', current)
print('  products_old_table:', old)
print('  total_rows:', total)
print('  total_revenue:', float(total_revenue) if total_revenue is not None else None)
print('  distinct_clients:', distinct_clients)
print('  date_range:', min_date, '->', max_date)
