#!/usr/bin/env python3
import os
from sqlalchemy import create_engine, text

NEON_URL = os.getenv('NEON_DATABASE_URL') or 'postgresql://neondb_owner:npg_kVbLoqca31Kv@ep-mute-sound-acp86gdj-pooler.sa-east-1.aws.neon.tech/neondb?sslmode=require&channel_binding=require'
engine = create_engine(NEON_URL, future=True)

with engine.connect() as conn:
    total = conn.execute(text('SELECT COUNT(*) FROM products_prod')).scalar()
    total_revenue = conn.execute(text('SELECT SUM(revenue) FROM products_prod')).scalar()
    distinct_clients = conn.execute(text('SELECT COUNT(DISTINCT client) FROM products_prod')).scalar()
    min_date = conn.execute(text('SELECT MIN(date) FROM products_prod')).scalar()
    max_date = conn.execute(text('SELECT MAX(date) FROM products_prod')).scalar()

print('NEON products_prod:')
print('  total_rows:', total)
print('  total_revenue:', float(total_revenue) if total_revenue is not None else None)
print('  distinct_clients:', distinct_clients)
print('  date_range:', min_date, '->', max_date)
