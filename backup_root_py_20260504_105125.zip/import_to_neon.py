#!/usr/bin/env python3
import os
import pandas as pd
from sqlalchemy import create_engine, text

NEON_URL = os.getenv('NEON_DATABASE_URL') or 'postgresql://neondb_owner:npg_kVbLoqca31Kv@ep-mute-sound-acp86gdj-pooler.sa-east-1.aws.neon.tech/neondb?sslmode=require&channel_binding=require'

engine = create_engine(NEON_URL, future=True)

# Read exported CSV
df = pd.read_csv('products_export.csv')

with engine.begin() as conn:
    # Create table if not exists (simple schema)
    conn.execute(text('''
    CREATE TABLE IF NOT EXISTS products (
        id BIGINT PRIMARY KEY,
        external_id TEXT,
        client TEXT,
        category TEXT,
        revenue NUMERIC,
        status TEXT,
        region TEXT,
        date TIMESTAMP,
        is_synthetic BOOLEAN
    );
    '''))
    # Insert rows using pandas to_sql via raw connection
    # Use upsert behavior: attempt insert, if conflict on id then update
    for i, row in df.iterrows():
        stmt = text('''
        INSERT INTO products (id, external_id, client, category, revenue, status, region, date, is_synthetic)
        VALUES (:id, :external_id, :client, :category, :revenue, :status, :region, :date, :is_synthetic)
        ON CONFLICT (id) DO UPDATE SET
            external_id = EXCLUDED.external_id,
            client = EXCLUDED.client,
            category = EXCLUDED.category,
            revenue = EXCLUDED.revenue,
            status = EXCLUDED.status,
            region = EXCLUDED.region,
            date = EXCLUDED.date,
            is_synthetic = EXCLUDED.is_synthetic;
        ''')
        params = {
            'id': int(row['id']) if not pd.isna(row['id']) else None,
            'external_id': row.get('external_id'),
            'client': row.get('client'),
            'category': row.get('category'),
            'revenue': float(row.get('revenue') or 0),
            'status': row.get('status'),
            'region': row.get('region'),
            'date': row.get('date'),
            'is_synthetic': bool(row.get('is_synthetic'))
        }
        conn.execute(stmt, params)

print('IMPORT_DONE', len(df))
