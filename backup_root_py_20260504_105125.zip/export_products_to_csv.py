#!/usr/bin/env python3
from backend.db import SessionLocal
from backend.models.product import Product
import pandas as pd

db = SessionLocal()
rows = db.query(Product).all()

data = []
for r in rows:
    data.append({
        "id": r.id,
        "external_id": getattr(r, 'external_id', None),
        "client": getattr(r, 'client', None),
        "category": getattr(r, 'category', None),
        "revenue": float(getattr(r, 'revenue', 0) or 0),
        "status": getattr(r, 'status', None),
        "region": getattr(r, 'region', None),
        "date": getattr(r, 'date', None),
        "is_synthetic": bool(getattr(r, 'is_synthetic', False)),
    })

df = pd.DataFrame(data)
df.to_csv('products_export.csv', index=False)
print('EXPORT_DONE', len(df))
