#!/usr/bin/env python3
import os
from sqlalchemy import create_engine, text

NEON_URL = os.getenv('NEON_DATABASE_URL') or 'postgresql://neondb_owner:npg_kVbLoqca31Kv@ep-mute-sound-acp86gdj-pooler.sa-east-1.aws.neon.tech/neondb?sslmode=require&channel_binding=require'
engine = create_engine(NEON_URL, future=True)

with engine.begin() as conn:
    existing_products = conn.execute(text("SELECT to_regclass('public.products')")).scalar()
    promoted_products = conn.execute(text("SELECT to_regclass('public.products_prod')")).scalar()

    if existing_products:
        conn.execute(text("ALTER TABLE products RENAME TO products_old;"))
    if promoted_products:
        conn.execute(text("ALTER TABLE products_prod RENAME TO products;"))
    else:
        raise RuntimeError('products_prod não existe no Neon')

print('SWAP_DONE')
