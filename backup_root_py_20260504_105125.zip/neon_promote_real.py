#!/usr/bin/env python3
import os
from sqlalchemy import create_engine, text

NEON_URL = os.getenv('NEON_DATABASE_URL') or 'postgresql://neondb_owner:npg_kVbLoqca31Kv@ep-mute-sound-acp86gdj-pooler.sa-east-1.aws.neon.tech/neondb?sslmode=require&channel_binding=require'
engine = create_engine(NEON_URL, future=True)

with engine.begin() as conn:
    conn.execute(text('''
    CREATE TABLE IF NOT EXISTS products_prod (
        id BIGINT PRIMARY KEY,
        external_id TEXT,
        client TEXT,
        category TEXT,
        revenue NUMERIC,
        status TEXT,
        region TEXT,
        date TIMESTAMP
    );
    '''))
    # Insert only non-synthetic rows from products_import
    conn.execute(text('''
    INSERT INTO products_prod (id, external_id, client, category, revenue, status, region, date)
    SELECT id, external_id, client, category, revenue, status, region, date
    FROM products_import
    WHERE is_synthetic = false
    ON CONFLICT (id) DO UPDATE SET
      external_id = EXCLUDED.external_id,
      client = EXCLUDED.client,
      category = EXCLUDED.category,
      revenue = EXCLUDED.revenue,
      status = EXCLUDED.status,
      region = EXCLUDED.region,
      date = EXCLUDED.date;
    '''))

print('PROMOTE_DONE')
