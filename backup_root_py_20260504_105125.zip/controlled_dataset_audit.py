#!/usr/bin/env python3
import importlib
import os
import sys
from dataclasses import dataclass
from datetime import date
from pathlib import Path


@dataclass
class Row:
    id: int
    external_id: int
    client: str
    category: str
    revenue: float
    status: str
    date: date
    is_synthetic: bool = False


SCENARIOS = {
    'small_2_rows': [
        Row(1, 1001, 'Alpha', 'A', 100.0, 'Completed', date(2024, 1, 15)),
        Row(2, 1002, 'Beta', 'B', 150.0, 'Processing', date(2024, 1, 15)),
    ],
    'same_day_concentrated': [
        Row(1, 2001, 'Gamma', 'A', 50.0, 'Completed', date(2024, 2, 1)),
        Row(2, 2002, 'Delta', 'A', 75.0, 'Completed', date(2024, 2, 1)),
        Row(3, 2003, 'Epsilon', 'B', 125.0, 'Shipped', date(2024, 2, 1)),
        Row(4, 2004, 'Zeta', 'B', 100.0, 'Processing', date(2024, 2, 1)),
    ],
    'gaps_series': [
        Row(1, 3001, 'Gap One', 'A', 10.0, 'Completed', date(2024, 3, 1)),
        Row(2, 3002, 'Gap Two', 'A', 20.0, 'Completed', date(2024, 3, 10)),
        Row(3, 3003, 'Gap Three', 'B', 30.0, 'Completed', date(2024, 3, 28)),
    ],
    'multi_category': [
        Row(1, 4001, 'One', 'A', 300.0, 'Completed', date(2024, 4, 1)),
        Row(2, 4002, 'Two', 'B', 200.0, 'Completed', date(2024, 4, 2)),
        Row(3, 4003, 'Three', 'C', 500.0, 'Completed', date(2024, 4, 3)),
        Row(4, 4004, 'Four', 'C', 100.0, 'Processing', date(2024, 4, 4)),
        Row(5, 4005, 'Five', 'B', 400.0, 'Shipped', date(2024, 4, 5)),
        Row(6, 4006, 'Six', 'A', 50.0, 'Pending', date(2024, 4, 6)),
    ],
}


def load_modules(db_url: str):
    os.environ['DATABASE_URL'] = db_url
    for name in list(sys.modules):
        if name == 'backend.db' or name.startswith('backend.models') or name.startswith('backend.services'):
            del sys.modules[name]
    db = importlib.import_module('backend.db')
    product_module = importlib.import_module('backend.models.product')
    analytics = importlib.import_module('backend.services.analytics')
    products = importlib.import_module('backend.services.products')
    return db, product_module.Product, analytics, products


def seed_database(db_module, Product, rows):
    db_module.Base.metadata.drop_all(bind=db_module.engine)
    db_module.Base.metadata.create_all(bind=db_module.engine)

    session = db_module.SessionLocal()
    try:
        for row in rows:
            session.add(
                Product(
                    id=row.id,
                    external_id=row.external_id,
                    client=row.client,
                    category=row.category,
                    revenue=row.revenue,
                    status=row.status,
                    date=row.date,
                    is_synthetic=row.is_synthetic,
                )
            )
        session.commit()
    finally:
        session.close()


def summarize_distribution(data):
    total = sum(item['count'] for item in data) if data else 0
    percentages = [round((item['count'] / total) * 100, 2) for item in data] if total else []
    return total, percentages, round(sum(percentages), 2) if percentages else 0.0


def run_scenario(name, rows):
    db_url = f'sqlite:///./audit_{name}.db'
    db_module, Product, analytics, products = load_modules(db_url)
    seed_database(db_module, Product, rows)

    sales_monthly = analytics.get_sales_monthly()
    sales_trend = analytics.get_sales_trend(range_value='30d')
    distribution = analytics.get_distribution_category()
    top_products = analytics.get_top_products(limit=10)
    product_list = products.get_products_service('all', 'all', 'all', 'all', '', 1, 10, 'date', 'desc')

    dist_total, dist_percentages, dist_percent_sum = summarize_distribution(distribution.get('data', []))
    top_revenues = [item['revenue'] for item in top_products.get('data', [])]
    top_sorted_desc = all(top_revenues[i] >= top_revenues[i + 1] for i in range(len(top_revenues) - 1))

    print(f'=== {name} ===')
    print('sales_monthly_state:', sales_monthly.get('state'), 'points:', len(sales_monthly.get('data', [])), 'orders_sum:', sum(p['orders'] for p in sales_monthly.get('data', [])))
    print('sales_trend_state:', sales_trend.get('state'), 'points:', len(sales_trend.get('data', [])))
    print('distribution_state:', distribution.get('state'), 'total_count:', dist_total, 'percent_sum:', dist_percent_sum)
    print('top_products_state:', top_products.get('state'), 'sorted_desc:', top_sorted_desc)
    print('products_total:', product_list.total, 'items:', len(product_list.items))
    print('distribution_percentages:', dist_percentages)
    print()


def main():
    for name, rows in SCENARIOS.items():
        run_scenario(name, rows)


if __name__ == '__main__':
    main()